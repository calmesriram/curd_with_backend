import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  formGroup: FormGroup;
  constructor(private formBuilder: FormBuilder, public api: ApiService,public router:Router) { }

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      'username': ['', Validators.required],
      'password': ['', Validators.required],
    });
  }

  createForm() {
    console.log(this.formGroup.value)
    this.api.login(this.formGroup.value).then(res => {
      console.log(res)
      sessionStorage.setItem("token",res?.['token']);
      sessionStorage.setItem("username",res['data'][0]['username']);
      this.router.navigateByUrl('/user');
      // window.location.reload();
    }).catch(e => {
      console.log(e)
    })
  }

}
