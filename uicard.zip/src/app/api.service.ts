import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Observer, fromEvent, merge } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  public baseurl: String = "http://localhost:3000"
  public headers_object = new HttpHeaders({
    'Content-Type': 'application/json',
    'access-token': sessionStorage.getItem("token")
  });
  public img_headers_object = new HttpHeaders({
    'access-token': sessionStorage.getItem("token")
  });
  constructor(public http: HttpClient) { }

  getDetails() {
    let a = { "username": sessionStorage.getItem("username") }
    return new Promise((resolve, reject) => {
      this.http.post(this.baseurl + "/View", a, { headers: this.headers_object }).subscribe(res => {
        resolve(res);
      }, err => {
        resolve(err);
        // const formData: FormData = new FormData();
        // formData.append("ClinicName",docpro.clinicname);
        // formData.append("ClinicLogo",imgfile);
      })
    })
  }

  createDetail(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.baseurl + "/Create/", data,{ headers: this.img_headers_object }).subscribe(res => {
        resolve(res);
      }, err => {
        resolve(err);
      })
    })
  }

  deleteDetail(id) {
    let a = { "newsid": id }
    return new Promise((resolve, reject) => {
      this.http.post(this.baseurl + "/Delete/", a,{ headers: this.headers_object }).subscribe(res => {
        resolve(res);
      }, err => {
        resolve(err);
      })
    })
  }

  login(data){
    return new Promise((resolve, reject) => {
      this.http.post(this.baseurl + "/login/", data).subscribe(res => {
        resolve(res);
      }, err => {
        resolve(err);
      })
    })
  }
}
