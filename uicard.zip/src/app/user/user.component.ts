import { AfterViewInit, OnInit, Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'description', 'image', 'view', 'update', 'delete'];
  dataSource = new MatTableDataSource()
  myselecteddata: any;
  boolencard: boolean = false;
  createform: FormGroup;
  filesToUpload: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  constructor(public api: ApiService, public _formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.createform = this._formBuilder.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
    this.getdetails();
  }

  getdetails() {
    this.api.getDetails().then(data => {
      this.dataSource = new MatTableDataSource(data['data']);
      setTimeout(() => { this.dataSource.paginator = this.paginator });
      console.log(data)
    })
  }

  selecteddata(e) {
    this.myselecteddata = e;
    console.log(e)
    this.boolencard = true;
  }
  closecard() {
    this.boolencard = false;
  }

  deletedata(id) {
    this.api.deleteDetail(id.newsid).then(data => {
      // console.log(data)
      this.getdetails();
    }).catch(e => {
      console.log(e)
    })
  }
  updateData(id) {
    console.log(id)
  }
  choose(event) {
    this.filesToUpload = event.target.files[0];
  }
  Create() {
    const formData = new FormData();
    formData.append('profile', this.filesToUpload);
    formData.append('username', "sriram");
    formData.append('name', this.createform.value.name);
    formData.append('description', this.createform.value.description);
    // console.log(formData)

    this.api.createDetail(formData).then(res => {
      // console.log(res)
      this.getdetails()
    })

  }
}
